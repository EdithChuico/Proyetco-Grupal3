package com.mycompany.p2taller1chuicoedith;
import com.mongodb.client.FindIterable;
import org.bson.Document;  
import com.mongodb.client.MongoClient;
import com.mongodb.client.MongoClients;
import com.mongodb.client.MongoCollection;
import com.mongodb.client.MongoDatabase;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.FileWriter;
import java.io.IOException;
import java.text.DecimalFormat;
import javax.swing.JOptionPane;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;
public class Inventario extends javax.swing.JFrame {
     private final MongoInicio mongoInicio;
     private final MongoNocom mongoNocom;
     private javax.swing.Timer timer;
         private int barraX;
    public Inventario() {
        initComponents();
        
        this.setExtendedState(this.MAXIMIZED_BOTH);
        Venta.setVisible(false);
        Modificar.setVisible(true);
        mongoInicio = new MongoInicio();
        mongoNocom = new MongoNocom();
        barraX = jPanel5.getX();
        cargarDatosDesdeMongo();
        cargarDatosDesdeMongoo();
        cargarDatosDesdeMongooo();
        //cargarDatosDesdeMongoooo();
        cargarDatosDesdeMongo1();
        cargarDatosDesdeMongo2();
    }
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jDialog1 = new javax.swing.JDialog();
        jDialog2 = new javax.swing.JDialog();
        panel1 = new java.awt.Panel();
        jDialog3 = new javax.swing.JDialog();
        jFileChooser1 = new javax.swing.JFileChooser();
        jPanel5 = new javax.swing.JPanel();
        salir = new javax.swing.JButton();
        registro = new javax.swing.JButton();
        inventario = new javax.swing.JButton();
        inve = new javax.swing.JButton();
        venta = new javax.swing.JButton();
        jLabel11 = new javax.swing.JLabel();
        jButton1 = new javax.swing.JButton();
        Modificar = new javax.swing.JTabbedPane();
        jPanel1 = new javax.swing.JPanel();
        jLabel15 = new javax.swing.JLabel();
        jLabel16 = new javax.swing.JLabel();
        noComestibles2 = new javax.swing.JTextField();
        codigo1 = new javax.swing.JTextField();
        nstockC = new javax.swing.JTextField();
        GuardarNocom = new java.awt.Button();
        jLabel17 = new javax.swing.JLabel();
        jLabel18 = new javax.swing.JLabel();
        jLabel19 = new javax.swing.JLabel();
        jScrollPane6 = new javax.swing.JScrollPane();
        Aderezos = new javax.swing.JTable();
        ActualizarNocom = new java.awt.Button();
        jLabel24 = new javax.swing.JLabel();
        jPanel3 = new javax.swing.JPanel();
        jScrollPane3 = new javax.swing.JScrollPane();
        jTable3 = new javax.swing.JTable();
        button4 = new java.awt.Button();
        jTabbedPane5 = new javax.swing.JTabbedPane();
        jPanel4 = new javax.swing.JPanel();
        nuevoNombre = new javax.swing.JTextField();
        jLabel6 = new javax.swing.JLabel();
        guardarNombre = new java.awt.Button();
        busqueda1 = new java.awt.Button();
        stock1 = new javax.swing.JTextField();
        jLabel7 = new javax.swing.JLabel();
        jLabel8 = new javax.swing.JLabel();
        jScrollPane7 = new javax.swing.JScrollPane();
        jTableNombre = new javax.swing.JTable();
        jLabel20 = new javax.swing.JLabel();
        jPanel6 = new javax.swing.JPanel();
        nuevostock = new javax.swing.JTextField();
        jLabel22 = new javax.swing.JLabel();
        guardar = new java.awt.Button();
        stock = new javax.swing.JTextField();
        busqueda = new java.awt.Button();
        jLabel3 = new javax.swing.JLabel();
        jLabel23 = new javax.swing.JLabel();
        jScrollPane9 = new javax.swing.JScrollPane();
        jTableStock = new javax.swing.JTable();
        jLabel14 = new javax.swing.JLabel();
        jPanel7 = new javax.swing.JPanel();
        eliminar = new java.awt.Button();
        codel = new javax.swing.JTextField();
        busquedaelim = new java.awt.Button();
        jLabel25 = new javax.swing.JLabel();
        jLabel26 = new javax.swing.JLabel();
        jScrollPane10 = new javax.swing.JScrollPane();
        jTableEliminar = new javax.swing.JTable();
        jLabel27 = new javax.swing.JLabel();
        jPanel2 = new javax.swing.JPanel();
        GuardarC = new java.awt.Button();
        jLabel5 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jLabel10 = new javax.swing.JLabel();
        jScrollPane1 = new javax.swing.JScrollPane();
        comestiblen = new javax.swing.JTextPane();
        jScrollPane4 = new javax.swing.JScrollPane();
        codigo = new javax.swing.JTextPane();
        jScrollPane2 = new javax.swing.JScrollPane();
        stockC = new javax.swing.JTextPane();
        jScrollPane5 = new javax.swing.JScrollPane();
        Sabores = new javax.swing.JTable();
        button2 = new java.awt.Button();
        jLabel13 = new javax.swing.JLabel();
        Venta = new javax.swing.JPanel();
        jScrollPane8 = new javax.swing.JScrollPane();
        tablafactura = new javax.swing.JTable();
        totalfinal = new javax.swing.JTextField();
        jLabel28 = new javax.swing.JLabel();
        jLabel29 = new javax.swing.JLabel();
        iva = new javax.swing.JTextField();
        jLabel30 = new javax.swing.JLabel();
        finaaal = new javax.swing.JTextField();
        button1 = new java.awt.Button();
        jLabel31 = new javax.swing.JLabel();
        jPanel9 = new javax.swing.JPanel();
        jLabel33 = new javax.swing.JLabel();
        jLabel35 = new javax.swing.JLabel();
        jLabel36 = new javax.swing.JLabel();
        jComboBox1 = new javax.swing.JComboBox<>();
        jLabel37 = new javax.swing.JLabel();
        cedula = new javax.swing.JTextField();
        telef = new javax.swing.JTextField();
        nombrec = new javax.swing.JTextField();
        busqueda3 = new java.awt.Button();
        jScrollPane11 = new javax.swing.JScrollPane();
        jTextPane1 = new javax.swing.JTextPane();
        Inventario = new javax.swing.JPanel();
        jScrollPane12 = new javax.swing.JScrollPane();
        sabores = new javax.swing.JTable();
        jScrollPane13 = new javax.swing.JScrollPane();
        aderezos = new javax.swing.JTable();
        ManualUsuario = new javax.swing.JPanel();

        javax.swing.GroupLayout jDialog1Layout = new javax.swing.GroupLayout(jDialog1.getContentPane());
        jDialog1.getContentPane().setLayout(jDialog1Layout);
        jDialog1Layout.setHorizontalGroup(
            jDialog1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 400, Short.MAX_VALUE)
        );
        jDialog1Layout.setVerticalGroup(
            jDialog1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 300, Short.MAX_VALUE)
        );

        javax.swing.GroupLayout jDialog2Layout = new javax.swing.GroupLayout(jDialog2.getContentPane());
        jDialog2.getContentPane().setLayout(jDialog2Layout);
        jDialog2Layout.setHorizontalGroup(
            jDialog2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 400, Short.MAX_VALUE)
        );
        jDialog2Layout.setVerticalGroup(
            jDialog2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 300, Short.MAX_VALUE)
        );

        javax.swing.GroupLayout panel1Layout = new javax.swing.GroupLayout(panel1);
        panel1.setLayout(panel1Layout);
        panel1Layout.setHorizontalGroup(
            panel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 100, Short.MAX_VALUE)
        );
        panel1Layout.setVerticalGroup(
            panel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 100, Short.MAX_VALUE)
        );

        javax.swing.GroupLayout jDialog3Layout = new javax.swing.GroupLayout(jDialog3.getContentPane());
        jDialog3.getContentPane().setLayout(jDialog3Layout);
        jDialog3Layout.setHorizontalGroup(
            jDialog3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 400, Short.MAX_VALUE)
        );
        jDialog3Layout.setVerticalGroup(
            jDialog3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 300, Short.MAX_VALUE)
        );

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setUndecorated(true);
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jPanel5.setLayout(null);

        salir.setBorder(null);
        salir.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        salir.setBorder(null);
        salir.setOpaque(false);
        salir.setContentAreaFilled(false);
        salir.setBorderPainted(false);
        salir.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                salirActionPerformed(evt);
            }
        });
        jPanel5.add(salir);
        salir.setBounds(100, 660, 320, 50);

        registro.setBorder(null);
        registro.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        registro.setBorder(null);
        registro.setOpaque(false);
        registro.setContentAreaFilled(false);
        registro.setBorderPainted(false);
        registro.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                registroActionPerformed(evt);
            }
        });
        jPanel5.add(registro);
        registro.setBounds(100, 600, 320, 50);

        inventario.setBorder(null);
        inventario.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        inventario.setBorder(null);
        inventario.setOpaque(false);
        inventario.setContentAreaFilled(false);
        inventario.setBorderPainted(false);
        inventario.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                inventarioActionPerformed(evt);
            }
        });
        jPanel5.add(inventario);
        inventario.setBounds(100, 470, 320, 50);

        inve.setBorder(null);
        inve.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        inve.setBorder(null);
        inve.setOpaque(false);
        inve.setContentAreaFilled(false);
        inve.setBorderPainted(false);
        inve.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                inveActionPerformed(evt);
            }
        });
        jPanel5.add(inve);
        inve.setBounds(110, 340, 310, 60);

        venta.setBorder(null);
        venta.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        venta.setBorder(null);
        venta.setOpaque(false);
        venta.setContentAreaFilled(false);
        venta.setBorderPainted(false);
        venta.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ventaActionPerformed(evt);
            }
        });
        jPanel5.add(venta);
        venta.setBounds(100, 410, 320, 50);

        jLabel11.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/Regsitro.png"))); // NOI18N
        jPanel5.add(jLabel11);
        jLabel11.setBounds(0, -10, 520, 790);

        jButton1.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jButton1.setBorder(null);
        jButton1.setOpaque(false);
        jButton1.setContentAreaFilled(false);
        jButton1.setBorderPainted(false);
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });
        jPanel5.add(jButton1);
        jButton1.setBounds(415, 30, 70, 50);

        getContentPane().add(jPanel5, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 520, 780));

        jPanel1.setLayout(null);

        jLabel15.setBackground(new java.awt.Color(255, 255, 255));
        jLabel15.setFont(new java.awt.Font("Wide Latin", 1, 14)); // NOI18N
        jLabel15.setText("Registro de Aderezos");
        jPanel1.add(jLabel15);
        jLabel15.setBounds(280, 10, 260, 40);

        jLabel16.setText("Nombre del aderezo:");
        jPanel1.add(jLabel16);
        jLabel16.setBounds(180, 80, 140, 14);

        noComestibles2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                noComestibles2ActionPerformed(evt);
            }
        });
        jPanel1.add(noComestibles2);
        noComestibles2.setBounds(410, 70, 200, 30);

        codigo1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                codigo1ActionPerformed(evt);
            }
        });
        jPanel1.add(codigo1);
        codigo1.setBounds(410, 120, 200, 30);

        nstockC.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                nstockCActionPerformed(evt);
            }
        });
        jPanel1.add(nstockC);
        nstockC.setBounds(410, 180, 200, 30);

        GuardarNocom.setBackground(new java.awt.Color(255, 255, 255));
        GuardarNocom.setFont(new java.awt.Font("Eras Demi ITC", 0, 12)); // NOI18N
        GuardarNocom.setLabel("Guardar");
        GuardarNocom.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                GuardarNocomActionPerformed(evt);
            }
        });
        jPanel1.add(GuardarNocom);
        GuardarNocom.setBounds(180, 250, 61, 24);

        jLabel17.setText("Código del aderezo:");
        jPanel1.add(jLabel17);
        jLabel17.setBounds(180, 130, 130, 20);

        jLabel18.setFont(new java.awt.Font("Segoe UI", 2, 8)); // NOI18N
        jLabel18.setForeground(new java.awt.Color(255, 0, 0));
        jLabel18.setText("Una letra acompañada de tres numeros");
        jPanel1.add(jLabel18);
        jLabel18.setBounds(430, 150, 150, 11);

        jLabel19.setText("Porciones:");
        jPanel1.add(jLabel19);
        jLabel19.setBounds(180, 190, 130, 14);

        Aderezos.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {

            }
        ));
        jScrollPane6.setViewportView(Aderezos);

        jPanel1.add(jScrollPane6);
        jScrollPane6.setBounds(100, 330, 560, 180);

        ActualizarNocom.setBackground(new java.awt.Color(255, 255, 255));
        ActualizarNocom.setFont(new java.awt.Font("Dialog", 1, 12)); // NOI18N
        ActualizarNocom.setForeground(new java.awt.Color(0, 0, 0));
        ActualizarNocom.setLabel("Actualizar");
        ActualizarNocom.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ActualizarNocomActionPerformed(evt);
            }
        });
        jPanel1.add(ActualizarNocom);
        ActualizarNocom.setBounds(510, 250, 73, 24);

        jLabel24.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel24.setText("Aderezos Totales");
        jPanel1.add(jLabel24);
        jLabel24.setBounds(320, 300, 130, 20);

        Modificar.addTab("Aderezos", jPanel1);

        jTable3.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        jScrollPane3.setViewportView(jTable3);

        button4.setBackground(new java.awt.Color(255, 255, 255));
        button4.setFont(new java.awt.Font("Dialog", 1, 12)); // NOI18N
        button4.setForeground(new java.awt.Color(0, 0, 0));
        button4.setLabel("Actualizar");
        button4.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                button4ActionPerformed(evt);
            }
        });

        jPanel4.setBackground(new java.awt.Color(255, 255, 255));
        jPanel4.setLayout(null);

        nuevoNombre.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                nuevoNombreActionPerformed(evt);
            }
        });
        jPanel4.add(nuevoNombre);
        nuevoNombre.setBounds(350, 160, 143, 22);

        jLabel6.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jLabel6.setText("Ingrese el nuevo nombre: ");
        jPanel4.add(jLabel6);
        jLabel6.setBounds(200, 160, 146, 16);

        guardarNombre.setBackground(new java.awt.Color(255, 255, 255));
        guardarNombre.setFont(new java.awt.Font("Dialog", 1, 12)); // NOI18N
        guardarNombre.setForeground(new java.awt.Color(0, 0, 0));
        guardarNombre.setLabel("Guardar ");
        guardarNombre.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                guardarNombreActionPerformed(evt);
            }
        });
        jPanel4.add(guardarNombre);
        guardarNombre.setBounds(520, 160, 65, 24);

        busqueda1.setBackground(new java.awt.Color(255, 255, 255));
        busqueda1.setFont(new java.awt.Font("Dialog", 1, 12)); // NOI18N
        busqueda1.setForeground(new java.awt.Color(0, 0, 0));
        busqueda1.setLabel("Buscar ");
        busqueda1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                busqueda1ActionPerformed(evt);
            }
        });
        jPanel4.add(busqueda1);
        busqueda1.setBounds(630, 40, 60, 24);
        jPanel4.add(stock1);
        stock1.setBounds(410, 40, 204, 22);

        jLabel7.setFont(new java.awt.Font("Segoe UI Black", 1, 18)); // NOI18N
        jLabel7.setText("Cambio de Nombre del Producto");
        jPanel4.add(jLabel7);
        jLabel7.setBounds(20, 10, 310, 20);

        jLabel8.setFont(new java.awt.Font("Perpetua", 1, 14)); // NOI18N
        jLabel8.setText("Ingrese porfavor el código del producto que desee modificar");
        jPanel4.add(jLabel8);
        jLabel8.setBounds(30, 40, 380, 17);

        jTableNombre.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Código", "Producto", "Stock", "Precio"
            }
        ));
        jScrollPane7.setViewportView(jTableNombre);

        jPanel4.add(jScrollPane7);
        jScrollPane7.setBounds(180, 80, 452, 40);

        jLabel20.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/icononombre.jpg"))); // NOI18N
        jPanel4.add(jLabel20);
        jLabel20.setBounds(50, 60, 90, 90);

        jTabbedPane5.addTab("Nombre", jPanel4);

        jPanel6.setBackground(new java.awt.Color(255, 255, 255));
        jPanel6.setLayout(null);

        nuevostock.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                nuevostockActionPerformed(evt);
            }
        });
        jPanel6.add(nuevostock);
        nuevostock.setBounds(350, 160, 143, 22);

        jLabel22.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jLabel22.setText("Ingrese el nuevo stock: ");
        jPanel6.add(jLabel22);
        jLabel22.setBounds(200, 160, 132, 16);

        guardar.setBackground(new java.awt.Color(255, 255, 255));
        guardar.setFont(new java.awt.Font("Dialog", 1, 12)); // NOI18N
        guardar.setForeground(new java.awt.Color(0, 0, 0));
        guardar.setLabel("Guardar ");
        guardar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                guardarActionPerformed(evt);
            }
        });
        jPanel6.add(guardar);
        guardar.setBounds(520, 160, 65, 24);
        jPanel6.add(stock);
        stock.setBounds(410, 40, 204, 22);

        busqueda.setBackground(new java.awt.Color(255, 255, 255));
        busqueda.setFont(new java.awt.Font("Dialog", 1, 12)); // NOI18N
        busqueda.setForeground(new java.awt.Color(0, 0, 0));
        busqueda.setLabel("Buscar ");
        busqueda.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                busquedaActionPerformed(evt);
            }
        });
        jPanel6.add(busqueda);
        busqueda.setBounds(630, 40, 60, 24);

        jLabel3.setFont(new java.awt.Font("Segoe UI Black", 1, 18)); // NOI18N
        jLabel3.setText("Cambio de Porciones");
        jPanel6.add(jLabel3);
        jLabel3.setBounds(20, 10, 230, 20);

        jLabel23.setFont(new java.awt.Font("Perpetua", 1, 14)); // NOI18N
        jLabel23.setText("Ingrese porfavor el código del producto que desee modificar");
        jPanel6.add(jLabel23);
        jLabel23.setBounds(30, 40, 380, 17);

        jTableStock.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Código", "Producto", "Stock", "Precio"
            }
        ));
        jScrollPane9.setViewportView(jTableStock);

        jPanel6.add(jScrollPane9);
        jScrollPane9.setBounds(180, 80, 452, 40);

        jLabel14.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/iconoCStock.jpg"))); // NOI18N
        jPanel6.add(jLabel14);
        jLabel14.setBounds(60, 70, 80, 80);

        jTabbedPane5.addTab("Stock\n", jPanel6);

        jPanel7.setBackground(new java.awt.Color(255, 255, 255));
        jPanel7.setLayout(null);

        eliminar.setBackground(new java.awt.Color(255, 255, 255));
        eliminar.setFont(new java.awt.Font("Dialog", 1, 12)); // NOI18N
        eliminar.setForeground(new java.awt.Color(0, 0, 0));
        eliminar.setLabel("Eliminar\n");
        eliminar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                eliminarActionPerformed(evt);
            }
        });
        jPanel7.add(eliminar);
        eliminar.setBounds(390, 130, 62, 24);
        jPanel7.add(codel);
        codel.setBounds(410, 40, 204, 22);

        busquedaelim.setBackground(new java.awt.Color(255, 255, 255));
        busquedaelim.setFont(new java.awt.Font("Dialog", 1, 12)); // NOI18N
        busquedaelim.setForeground(new java.awt.Color(0, 0, 0));
        busquedaelim.setLabel("Buscar ");
        busquedaelim.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                busquedaelimActionPerformed(evt);
            }
        });
        jPanel7.add(busquedaelim);
        busquedaelim.setBounds(630, 40, 60, 24);

        jLabel25.setFont(new java.awt.Font("Segoe UI Black", 1, 18)); // NOI18N
        jLabel25.setText("Eliminar Producto");
        jPanel7.add(jLabel25);
        jLabel25.setBounds(20, 10, 190, 20);

        jLabel26.setFont(new java.awt.Font("Perpetua", 1, 14)); // NOI18N
        jLabel26.setText("Ingrese porfavor el código del producto que desee eliminar");
        jPanel7.add(jLabel26);
        jLabel26.setBounds(30, 40, 380, 17);

        jTableEliminar.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Código", "Producto", "Stock", "Precio"
            }
        ));
        jScrollPane10.setViewportView(jTableEliminar);

        jPanel7.add(jScrollPane10);
        jScrollPane10.setBounds(180, 80, 452, 40);

        jLabel27.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/iconoElim.jpg"))); // NOI18N
        jPanel7.add(jLabel27);
        jLabel27.setBounds(40, 70, 80, 80);

        jTabbedPane5.addTab("Eliminar", jPanel7);

        javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(jPanel3);
        jPanel3.setLayout(jPanel3Layout);
        jPanel3Layout.setHorizontalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addGap(70, 70, 70)
                        .addComponent(jScrollPane3, javax.swing.GroupLayout.PREFERRED_SIZE, 630, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addGap(690, 690, 690)
                        .addComponent(button4, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addComponent(jTabbedPane5, javax.swing.GroupLayout.PREFERRED_SIZE, 790, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(54, Short.MAX_VALUE))
        );
        jPanel3Layout.setVerticalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jScrollPane3, javax.swing.GroupLayout.PREFERRED_SIZE, 190, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(10, 10, 10)
                .addComponent(button4, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(6, 6, 6)
                .addComponent(jTabbedPane5, javax.swing.GroupLayout.PREFERRED_SIZE, 277, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        Modificar.addTab("Modificar Inventario", jPanel3);

        jPanel2.setLayout(null);

        GuardarC.setBackground(new java.awt.Color(204, 204, 204));
        GuardarC.setFont(new java.awt.Font("Eras Demi ITC", 1, 12)); // NOI18N
        GuardarC.setLabel("Guardar");
        GuardarC.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                GuardarCActionPerformed(evt);
            }
        });
        jPanel2.add(GuardarC);
        GuardarC.setBounds(140, 280, 68, 22);

        jLabel5.setBackground(new java.awt.Color(255, 255, 255));
        jLabel5.setFont(new java.awt.Font("Wide Latin", 1, 14)); // NOI18N
        jLabel5.setText("Registro de Sabores ");
        jPanel2.add(jLabel5);
        jLabel5.setBounds(240, 0, 260, 50);

        jLabel4.setText("Nombre del Sabor");
        jPanel2.add(jLabel4);
        jLabel4.setBounds(130, 80, 160, 14);

        jLabel1.setText("Código del sabor:");
        jPanel2.add(jLabel1);
        jLabel1.setBounds(130, 140, 160, 16);

        jLabel2.setFont(new java.awt.Font("Segoe UI", 2, 8)); // NOI18N
        jLabel2.setForeground(new java.awt.Color(255, 0, 0));
        jLabel2.setText("Una letra acompañada de tres numeros");
        jPanel2.add(jLabel2);
        jLabel2.setBounds(440, 160, 135, 11);

        jLabel10.setText("Porciones disponibles");
        jPanel2.add(jLabel10);
        jLabel10.setBounds(120, 210, 160, 16);

        jScrollPane1.setViewportView(comestiblen);

        jPanel2.add(jScrollPane1);
        jScrollPane1.setBounds(400, 70, 235, 30);

        jScrollPane4.setViewportView(codigo);

        jPanel2.add(jScrollPane4);
        jScrollPane4.setBounds(400, 130, 235, 30);

        jScrollPane2.setViewportView(stockC);

        jPanel2.add(jScrollPane2);
        jScrollPane2.setBounds(400, 210, 235, 30);

        Sabores.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {

            }
        ));
        jScrollPane5.setViewportView(Sabores);

        jPanel2.add(jScrollPane5);
        jScrollPane5.setBounds(140, 360, 440, 150);

        button2.setBackground(new java.awt.Color(255, 255, 255));
        button2.setFont(new java.awt.Font("Dialog", 1, 12)); // NOI18N
        button2.setForeground(new java.awt.Color(0, 0, 0));
        button2.setLabel("Actualizar");
        button2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                button2ActionPerformed(evt);
            }
        });
        jPanel2.add(button2);
        button2.setBounds(440, 280, 73, 24);

        jLabel13.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel13.setText("Sabores Totales");
        jPanel2.add(jLabel13);
        jLabel13.setBounds(300, 330, 120, 25);

        Modificar.addTab("Sabores de Helado", jPanel2);

        getContentPane().add(Modificar, new org.netbeans.lib.awtextra.AbsoluteConstraints(520, 0, 850, 780));

        Venta.setLayout(null);

        tablafactura.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {

            }
        ));
        jScrollPane8.setViewportView(tablafactura);

        Venta.add(jScrollPane8);
        jScrollPane8.setBounds(180, 210, 607, 200);

        totalfinal.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                totalfinalActionPerformed(evt);
            }
        });
        Venta.add(totalfinal);
        totalfinal.setBounds(620, 430, 98, 22);

        jLabel28.setText("Precio total:");
        Venta.add(jLabel28);
        jLabel28.setBounds(540, 430, 63, 16);

        jLabel29.setText("IVA:");
        Venta.add(jLabel29);
        jLabel29.setBounds(580, 470, 21, 16);

        iva.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ivaActionPerformed(evt);
            }
        });
        Venta.add(iva);
        iva.setBounds(620, 470, 98, 22);

        jLabel30.setText("Precio Final:");
        Venta.add(jLabel30);
        jLabel30.setBounds(550, 510, 64, 16);

        finaaal.setText("56");
        finaaal.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                finaaalActionPerformed(evt);
            }
        });
        Venta.add(finaaal);
        finaaal.setBounds(620, 510, 98, 22);

        button1.setFont(new java.awt.Font("Dialog", 1, 12)); // NOI18N
        button1.setLabel("Registrar Factura");
        button1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                button1ActionPerformed(evt);
            }
        });
        Venta.add(button1);
        button1.setBounds(580, 560, 119, 24);

        jLabel31.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel31.setText("Facturación ");
        Venta.add(jLabel31);
        jLabel31.setBounds(389, 0, 104, 25);

        jPanel9.setBackground(new java.awt.Color(204, 204, 204));

        jLabel33.setText("Nombres y Apellidos del Cliente:");

        jLabel35.setText("N. Telefono:");

        jLabel36.setText("N. Cedula:");

        jComboBox1.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Efectivo ", "Transferencia" }));

        jLabel37.setText("Tipo de pago:");

        cedula.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cedulaActionPerformed(evt);
            }
        });

        telef.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                telefActionPerformed(evt);
            }
        });

        nombrec.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                nombrecActionPerformed(evt);
            }
        });

        busqueda3.setBackground(new java.awt.Color(255, 255, 255));
        busqueda3.setFont(new java.awt.Font("Dialog", 1, 12)); // NOI18N
        busqueda3.setForeground(new java.awt.Color(0, 0, 0));
        busqueda3.setLabel("BuscarClie\n");
        busqueda3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                busqueda3ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel9Layout = new javax.swing.GroupLayout(jPanel9);
        jPanel9.setLayout(jPanel9Layout);
        jPanel9Layout.setHorizontalGroup(
            jPanel9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel9Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel9Layout.createSequentialGroup()
                        .addComponent(jLabel33)
                        .addGap(32, 32, 32)
                        .addComponent(nombrec, javax.swing.GroupLayout.PREFERRED_SIZE, 376, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel9Layout.createSequentialGroup()
                        .addComponent(jLabel36)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(cedula, javax.swing.GroupLayout.PREFERRED_SIZE, 242, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(23, 23, 23)
                        .addComponent(busqueda3, javax.swing.GroupLayout.PREFERRED_SIZE, 95, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel9Layout.createSequentialGroup()
                        .addComponent(jLabel35)
                        .addGap(18, 18, 18)
                        .addComponent(telef, javax.swing.GroupLayout.PREFERRED_SIZE, 250, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel9Layout.createSequentialGroup()
                        .addComponent(jLabel37)
                        .addGap(18, 18, 18)
                        .addComponent(jComboBox1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addGap(184, 184, Short.MAX_VALUE))
        );
        jPanel9Layout.setVerticalGroup(
            jPanel9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel9Layout.createSequentialGroup()
                .addGap(12, 12, 12)
                .addGroup(jPanel9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(jLabel36)
                        .addComponent(cedula, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addComponent(busqueda3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel33)
                    .addComponent(nombrec, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(12, 12, 12)
                .addGroup(jPanel9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(telef, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel35))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel37)
                    .addComponent(jComboBox1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(0, 4, Short.MAX_VALUE))
        );

        Venta.add(jPanel9);
        jPanel9.setBounds(20, 40, 770, 140);

        jTextPane1.setText("          Promoción\nPor cada 10 dólares de compra para clientes registrados\nofrecemos el 10% de descuento en consumo.\n");
        jScrollPane11.setViewportView(jTextPane1);

        Venta.add(jScrollPane11);
        jScrollPane11.setBounds(10, 210, 150, 180);

        getContentPane().add(Venta, new org.netbeans.lib.awtextra.AbsoluteConstraints(520, 0, 850, 770));

        Inventario.setLayout(null);

        sabores.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        jScrollPane12.setViewportView(sabores);

        Inventario.add(jScrollPane12);
        jScrollPane12.setBounds(20, 50, 810, 320);

        aderezos.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Código", "Producto", "Stock", "Precio"
            }
        ));
        jScrollPane13.setViewportView(aderezos);

        Inventario.add(jScrollPane13);
        jScrollPane13.setBounds(20, 400, 810, 340);

        getContentPane().add(Inventario, new org.netbeans.lib.awtextra.AbsoluteConstraints(520, 0, 850, 770));

        javax.swing.GroupLayout ManualUsuarioLayout = new javax.swing.GroupLayout(ManualUsuario);
        ManualUsuario.setLayout(ManualUsuarioLayout);
        ManualUsuarioLayout.setHorizontalGroup(
            ManualUsuarioLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 850, Short.MAX_VALUE)
        );
        ManualUsuarioLayout.setVerticalGroup(
            ManualUsuarioLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 770, Short.MAX_VALUE)
        );

        getContentPane().add(ManualUsuario, new org.netbeans.lib.awtextra.AbsoluteConstraints(520, 0, 850, 770));

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void GuardarCActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_GuardarCActionPerformed
        try{
        String nombreC=comestiblen.getText();
        String stock=stockC.getText();
        String codi=codigo.getText();
        
    if (nombreC.isEmpty() || stock.isEmpty() || codi.isEmpty() ) {
        JOptionPane.showMessageDialog(this, "Todos los campos deben ser completados", "Error", JOptionPane.ERROR_MESSAGE);
        return; // Salir del método si hay campos vacíos
        }
        
    if (!codi.matches("[a-z]\\d{3}")) {
    JOptionPane.showMessageDialog(this, "Ingrese un código válido (una letra minúscula seguida de tres números)", "Error", JOptionPane.ERROR_MESSAGE);
    return;
    }
    
    try {
    int stockValue = Integer.parseInt(stock);
    if (stockValue < 1 || stockValue > 1000) {
        JOptionPane.showMessageDialog(this, "Ingrese un valor de stock válido (entre 1 y 1000)", "Error", JOptionPane.ERROR_MESSAGE);
        return;
    }
} catch (NumberFormatException e) {
    JOptionPane.showMessageDialog(this, "Ingrese un valor numérico válido para el stock", "Error", JOptionPane.ERROR_MESSAGE);
    return;
}

     try(MongoClient mongoClient = MongoClients.create("mongodb://localhost:27017")) {
                MongoDatabase database = mongoClient.getDatabase("ProyectoDeliFrost");
                MongoCollection<Document> collection = database.getCollection("Sabores");
                MongoCollection<Document> collectionn = database.getCollection("Inventario");
                 Document query = new Document("Código:", codi);
        long count = collection.countDocuments(query);
       if( count <= 0){
        }else {
            JOptionPane.showMessageDialog(this, "El codigo ya existe dentro de los datos ingresados, por favor ingrese un codigo distinto", "Error", JOptionPane.ERROR_MESSAGE);
            return;
       }
        try{
            String NLine="\n";
       
           String archivo= "archivoSabores.csv"; 
           FileWriter fw= new FileWriter(archivo,true);
           fw.append(NLine).append("Sabor de helado       | Codigo   | Porciones  ");
           fw.append(NLine).append(nombreC+"         |").append(codi+ "    |").append(stock+"   ");
           fw.append(NLine);
           fw.flush();
           fw.close();
           System.out.print("Archivo creado con exito");
            }catch(IOException e){
                e.printStackTrace();
            }
                    String resultado = nombreC.substring(0, 1).toUpperCase() + nombreC.substring(1).toLowerCase();
                    Document document = new Document()
                        .append("Producto:", resultado)
                        .append("Código:", codi)
                        .append("Porciones:", stock);
                        collection.insertOne(document);
                    Document documentAr = new Document()
                        .append("Producto:", resultado)
                        .append("Código:", codi)
                        .append("Porciones:", stock);
                     
                collectionn.insertOne(documentAr);
                JOptionPane.showMessageDialog(this, "Datos guardados correctamente en la base de datos", "Éxito", JOptionPane.INFORMATION_MESSAGE);
         }}  catch (NumberFormatException e) {
        JOptionPane.showMessageDialog(this, "Ingrese valores numéricos válidos para Stock y Precio", "Error", JOptionPane.ERROR_MESSAGE);
         }
        comestiblen.setText("");
        stockC.setText("");
        codigo.setText("");
    }//GEN-LAST:event_GuardarCActionPerformed

    private void button2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_button2ActionPerformed
        cargarDatosDesdeMongo();
        JOptionPane.showMessageDialog(this, "Tabla actualizada!", "Éxito", JOptionPane.INFORMATION_MESSAGE);
        // TODO add your handling code here:
    }//GEN-LAST:event_button2ActionPerformed
    private void cargarDatosDesdeMongoo() {
         FindIterable<Document> documents = mongoNocom.getAllDocumentscollectionn();
         DefaultTableModel tableModel = new DefaultTableModel();
         tableModel.setColumnIdentifiers(new String[]{ "Código de Producto","Producto","Porciones"});
         for (Document document : documents) {
             tableModel.addRow(new Object[]{
                 document.get("Código:"),
                 document.get("Producto:"),
                 document.get("Porciones:")
             });
         }
         Aderezos.setModel(tableModel);
    }
    private void noComestibles2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_noComestibles2ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_noComestibles2ActionPerformed

    private void codigo1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_codigo1ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_codigo1ActionPerformed

    private void nstockCActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_nstockCActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_nstockCActionPerformed

    private void GuardarNocomActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_GuardarNocomActionPerformed
        String nombreC=noComestibles2.getText();
        String stock1=nstockC.getText();
        String cod=codigo1.getText();
        if (nombreC.isEmpty() || cod.isEmpty() ||stock1.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Todos los campos deben ser completados", "Error", JOptionPane.ERROR_MESSAGE);
            return;}
        if (nombreC.matches("d")) {
            JOptionPane.showMessageDialog(this, "Ingrese un nombre valido", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }
        
        if (!cod.matches("[a-z]\\d{3}")) {
            JOptionPane.showMessageDialog(this, "Ingrese un código válido (una letra minúscula seguida de tres números)", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }
        try {
            int stockr = Integer.parseInt(stock1);
            if (stockr < 1 || stockr > 1000) {
                JOptionPane.showMessageDialog(this, "La cantidad de stock debe ser un número positivo entre 1 y 1000", "Error", JOptionPane.ERROR_MESSAGE);
                return;
            }
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(this, "La cantidad de stock debe ser un número válido entre 1 y 1000", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }
        
        
        try(MongoClient mongoClient = MongoClients.create("mongodb://localhost:27017")) {
            MongoDatabase database = mongoClient.getDatabase("ProyectoDeliFrost");
            MongoCollection<Document> collection = database.getCollection("Aderezos");
            MongoCollection<Document> collectionn = database.getCollection("Inventario");
            Document query = new Document("Código de Producto:", cod);
            long count = collection.countDocuments(query);
            if( count <= 0){
            }else {
                JOptionPane.showMessageDialog(this, "El codigo ya existe dentro de los datos ingresados, por favor ingrese un codigo distinto", "Error", JOptionPane.ERROR_MESSAGE);
                return;
            }
            try{
            String NLine="\n";
       
           String archivo= "archivoAderezos.csv"; 
           FileWriter fw= new FileWriter(archivo,true);
           fw.append(NLine).append("Aderezo       | Codigo   | Porciones  ");
           fw.append(NLine).append(nombreC+"       |").append(cod+ "       |").append(stock1+"   ");
           fw.append(NLine);
           fw.flush();
           fw.close();
           System.out.print("Archivo creado con exito");
            }catch(IOException e){
                e.printStackTrace();
            }
            String resultado = nombreC.substring(0, 1).toUpperCase() + nombreC.substring(1).toLowerCase();

            Document document = new Document()
            .append("Producto:", resultado)
            .append("Código:", cod)
            .append("Porciones:", stock1);
            collection.insertOne(document);
            collectionn.insertOne(document);
            JOptionPane.showMessageDialog(this, "Datos guardados correctamente en la base de datos", "Éxito", JOptionPane.INFORMATION_MESSAGE);

        }  catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(this, "Ingrese valores numéricos válidos para Stock y Precio", "Error", JOptionPane.ERROR_MESSAGE);
        }
        
        noComestibles2.setText("");
        nstockC.setText("");
        codigo.setText("");
    }//GEN-LAST:event_GuardarNocomActionPerformed

    private void ActualizarNocomActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ActualizarNocomActionPerformed
        cargarDatosDesdeMongoo();
        JOptionPane.showMessageDialog(this, "Tabla actualizada!", "Éxito", JOptionPane.INFORMATION_MESSAGE);
        // TODO add your handling code here:
    }//GEN-LAST:event_ActualizarNocomActionPerformed

    private void button4ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_button4ActionPerformed
        cargarDatosDesdeMongooo();
        JOptionPane.showMessageDialog(this, "Tabla actualizada!", "Éxito", JOptionPane.INFORMATION_MESSAGE);
        // TODO add your handling code here:
    }//GEN-LAST:event_button4ActionPerformed

    private void nuevoNombreActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_nuevoNombreActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_nuevoNombreActionPerformed

    private void guardarNombreActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_guardarNombreActionPerformed
        String codd = stock1.getText();
        String nuevoNom = nuevoNombre.getText();
        String Nombre = nuevoNom.substring(0, 1).toUpperCase() + nuevoNom.substring(1).toLowerCase();

        MongoClient mongoClient = MongoClients.create("mongodb://localhost:27017");
        MongoDatabase database = mongoClient.getDatabase("ProyectoDeliFrost");
        MongoCollection<Document> collectionn = database.getCollection("Inventario");
        MongoCollection<Document> collection = database.getCollection("Aderezos");
        MongoCollection<Document> collectionnn = database.getCollection("Sabores");

        Document query = new Document("Código:", codd);
        long count = collectionn.countDocuments(query);
        Document queryy = new Document("Producto:", Nombre);
        long counnt = collectionn.countDocuments(queryy);

        if (count <= 0) {
            JOptionPane.showMessageDialog(this, "El código ingresado no ha sido registrado", "Error", JOptionPane.ERROR_MESSAGE);
        } else {
            if(counnt <= 0){

                // Define la actualización que deseas realizar
                Document updateDocument = new Document("$set", new Document("Producto:", Nombre));
                // Realiza la actualización
                collectionn.updateOne(query, updateDocument);
                collection.updateOne(query, updateDocument);
                collectionnn.updateOne(query, updateDocument);
                JOptionPane.showMessageDialog(this, "Nombre del producto actualizado correctamente", "Éxito", JOptionPane.INFORMATION_MESSAGE);
            }else{
                JOptionPane.showMessageDialog(this, "El nombre ingresado ya existe para otro producto", "Error", JOptionPane.ERROR_MESSAGE);
            }}
            stock1.setText("");
            nuevoNombre.setText("");
    }//GEN-LAST:event_guardarNombreActionPerformed

    private void busqueda1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_busqueda1ActionPerformed
        String codd = stock1.getText();
        if (!codd.matches("[a-z]\\d{3}")) {
            JOptionPane.showMessageDialog(this, "Ingrese un código válido (una letra minúscula seguida de tres números)", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }MongoClient mongoClient = MongoClients.create("mongodb://localhost:27017");
        MongoDatabase database = mongoClient.getDatabase("ProyectoDeliFrost");
        MongoCollection<Document> collectionn = database.getCollection("Inventario");

        Document query = new Document("Código:", codd);
        long count = collectionn.countDocuments(query);
        if (count <= 0) {
            JOptionPane.showMessageDialog(this, "El código ingresado no a sido registrado", "Error", JOptionPane.ERROR_MESSAGE);
        } else {
            DefaultTableModel tableModel = (DefaultTableModel) jTableNombre.getModel();
            tableModel.setRowCount(0);
            FindIterable<Document> documents = collectionn.find(query);
            for (Document document : documents) {
                tableModel.addRow(new Object[]{
                    document.get("Código:"),
                    document.get("Producto:"),
                    document.get("Porciones:")
                });  }
                jTableNombre.setModel(tableModel);
                jTableNombre.revalidate();
                jTableNombre.repaint();
            }  // TODO add your handling code here:
    }//GEN-LAST:event_busqueda1ActionPerformed

    private void nuevostockActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_nuevostockActionPerformed

    }//GEN-LAST:event_nuevostockActionPerformed

    private void guardarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_guardarActionPerformed
        String cod = stock.getText();
        String nuevoStock = nuevostock.getText();
        try {
            int stockr = Integer.parseInt(nuevoStock);
            if (stockr < 1 || stockr > 1000) {
                JOptionPane.showMessageDialog(this, "La cantidad de stock debe ser un número positivo entre 1 y 1000", "Error", JOptionPane.ERROR_MESSAGE);
                return;
            }
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(this, "La cantidad de stock debe ser un número válido entre 1 y 1000", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }
        MongoClient mongoClient = MongoClients.create("mongodb://localhost:27017");
        MongoDatabase database = mongoClient.getDatabase("ProyectoDeliFrost");
        MongoCollection<Document> collectionn = database.getCollection("Inventario");
        MongoCollection<Document> collection = database.getCollection("Sabores");
        MongoCollection<Document> collectionnn = database.getCollection("Aderezos");
        Document query = new Document("Código:", cod);
        long count = collectionn.countDocuments(query);
        if (count <= 0) {
            JOptionPane.showMessageDialog(this, "El código ingresado no ha sido registrado", "Error", JOptionPane.ERROR_MESSAGE);
        } else {
            Document updateDocument = new Document("$set", new Document("Porciones:", nuevoStock));
            collectionn.updateOne(query, updateDocument);
            collection.updateOne(query, updateDocument);
            collectionnn.updateOne(query, updateDocument);
            JOptionPane.showMessageDialog(this, "Porciones totales actualizadas correctamente", "Éxito", JOptionPane.INFORMATION_MESSAGE);
        }
        stock.setText("");
        nuevostock.setText("");
    }//GEN-LAST:event_guardarActionPerformed

    private void busquedaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_busquedaActionPerformed
        String cod = stock.getText();
        if (!cod.matches("[a-z]\\d{3}")) {
            JOptionPane.showMessageDialog(this, "Ingrese un código válido (una letra minúscula seguida de tres números)", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }MongoClient mongoClient = MongoClients.create("mongodb://localhost:27017");
        MongoDatabase database = mongoClient.getDatabase("ProyectoDeliFrost");
        MongoCollection<Document> collectionn = database.getCollection("Inventario");

        Document query = new Document("Código:", cod);
        long count = collectionn.countDocuments(query);
        if (count <= 0) {
            JOptionPane.showMessageDialog(this, "El código ingresado no a sido registrado", "Error", JOptionPane.ERROR_MESSAGE);
        } else {
            DefaultTableModel tableModel = (DefaultTableModel) jTableStock.getModel();
            tableModel.setRowCount(0);
            FindIterable<Document> documents = collectionn.find(query);
            for (Document document : documents) {
                tableModel.addRow(new Object[]{
                    document.get("Código:"),
                    document.get("Producto:"),
                    document.get("Porciones:")
                });
            }
            jTableStock.setModel(tableModel);
            jTableStock.revalidate();
            jTableStock.repaint();
        }
    }//GEN-LAST:event_busquedaActionPerformed

    private void eliminarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_eliminarActionPerformed
        String cod = codel.getText();
        if (!cod.matches("[a-z]\\d{3}")) {
            JOptionPane.showMessageDialog(this, "Ingrese un código válido (una letra minúscula seguida de tres números)", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }try (MongoClient mongoClient = MongoClients.create("mongodb://localhost:27017")) {
            MongoDatabase database = mongoClient.getDatabase("ProyectoDeliFrost");
            MongoCollection<Document> collection = database.getCollection("Inventario");
            MongoCollection<Document> collectionn = database.getCollection("Sabores");
            MongoCollection<Document> collectionnn = database.getCollection("Aderezos");
            Document filter = new Document("Código:", cod);
            collection.deleteOne(filter);
            collectionn.deleteOne(filter);
            collectionnn.deleteOne(filter);
            JOptionPane.showMessageDialog(this, "El producto a sido eliminado correctamente", "Éxito", JOptionPane.INFORMATION_MESSAGE);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }//GEN-LAST:event_eliminarActionPerformed

    private void busquedaelimActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_busquedaelimActionPerformed
        String cod = codel.getText();
        if (!cod.matches("[a-z]\\d{3}")) {
            JOptionPane.showMessageDialog(this, "Ingrese un código válido (una letra minúscula seguida de tres números)", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }
        MongoClient mongoClient = MongoClients.create("mongodb://localhost:27017");
        MongoDatabase database = mongoClient.getDatabase("ProyectoDeliFrost");
        MongoCollection<Document> collectionn = database.getCollection("Inventario");

        Document query = new Document("Código:", cod);
        long count = collectionn.countDocuments(query);
        if (count <= 0) {
            JOptionPane.showMessageDialog(this, "El código ingresado no a sido registrado", "Error", JOptionPane.ERROR_MESSAGE);
        } else {
            DefaultTableModel tableModel = (DefaultTableModel) jTableEliminar.getModel();
            tableModel.setRowCount(0);
            FindIterable<Document> documents = collectionn.find(query);
            for (Document document : documents) {
                tableModel.addRow(new Object[]{
                    document.get("Código:"),
                    document.get("Producto:"),
                    document.get("Porciones:")
                });
            }
            jTableEliminar.setModel(tableModel);
            jTableEliminar.revalidate();
            jTableEliminar.repaint();
        }        // TODO add your handling code here:
    }//GEN-LAST:event_busquedaelimActionPerformed
     private void cargarDatosDesdeMongo1() {
         FindIterable<Document> documents = mongoNocom.getAllDocumentscollectionn();
         DefaultTableModel tableModel = new DefaultTableModel();
         tableModel.setColumnIdentifiers(new String[]{ "Código de Producto","Producto","Stock"});
         // Llena el modelo con los datos de MongoDB
         for (Document document : documents) {
             tableModel.addRow(new Object[]{
                 document.get("Código:"),
                 document.get("Producto:"),
                 document.get("Porciones:"),
             });} aderezos.setModel(tableModel);
    }
    private void cargarDatosDesdeMongo2() {
         FindIterable<Document> documents = mongoInicio.getAllDocumentscollectionn();
         DefaultTableModel tableModel = new DefaultTableModel();
         tableModel.setColumnIdentifiers(new String[]{ "Código de Producto","Producto","Stock"});
         // Llena el modelo con los datos de MongoDB
         for (Document document : documents) {
             tableModel.addRow(new Object[]{
                 document.get("Código:"),
                 document.get("Producto:"),
                    document.get("Porciones:")
             });} sabores.setModel(tableModel);
    }
    private void ventaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ventaActionPerformed
        Venta.setVisible(true);
        Modificar.setVisible(false);
        Inventario.setVisible(false);

     // TODO add your handling code here:
    }//GEN-LAST:event_ventaActionPerformed

    private void inventarioActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_inventarioActionPerformed
        Venta.setVisible(false);
        Modificar.setVisible(true);
        Inventario.setVisible(false);       // TODO add your handling code here:
    }//GEN-LAST:event_inventarioActionPerformed

    private void registroActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_registroActionPerformed
       Confirmar cf = new Confirmar();
       cf.setVisible(true);
       cf.setLocationRelativeTo(null);
// TODO add your handling code here:
    }//GEN-LAST:event_registroActionPerformed

    private void inveActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_inveActionPerformed
       Venta.setVisible(false);
        Modificar.setVisible(false);
        Inventario.setVisible(true);
// TODO add your handling code here:
    }//GEN-LAST:event_inveActionPerformed

    private void salirActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_salirActionPerformed
     System.exit(0);   // TODO add your handling code here:
    }//GEN-LAST:event_salirActionPerformed
    double totalf=0.0;
        double total=0;
    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
    if (jPanel5.isVisible()) {
        // Si la barra es visible, oculta la barra
        ocultarBarra();
    } else {
        // Si la barra está oculta, inicia el reseteo
        iniciarReset();
    }   // TODO add your handling code here:
    }//GEN-LAST:event_jButton1ActionPerformed

    private void nombrecActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_nombrecActionPerformed

    }//GEN-LAST:event_nombrecActionPerformed

    private void telefActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_telefActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_telefActionPerformed

    private void cedulaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cedulaActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_cedulaActionPerformed

    private void button1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_button1ActionPerformed
    try{
            String nombreC=nombrec.getText();
            String cedulaa=cedula.getText();
            String cel=telef.getText();
            
            if (nombreC.isEmpty() || nombreC.isEmpty() || cedulaa.isEmpty() || cel==null ) {
                JOptionPane.showMessageDialog(this, "Todos los campos deben ser completados", "Error", JOptionPane.ERROR_MESSAGE);
                return;
            }
            try{
                if (!cedulaa.matches("\\d{10}")) {
                    JOptionPane.showMessageDialog(this, "Ingrese una cedula válida", "Error", JOptionPane.ERROR_MESSAGE);
                    return;
                }} catch (NumberFormatException e) {
                    JOptionPane.showMessageDialog(this, "Ingrese una cedula válida", "Error", JOptionPane.ERROR_MESSAGE);
                    return;
                }
                try{
                    if (!cel.matches("\\d{10}")) {
                        JOptionPane.showMessageDialog(this, "Ingrese un numero de telefono válido", "Error", JOptionPane.ERROR_MESSAGE);
                        return;
                    }} catch (NumberFormatException e) {
                        JOptionPane.showMessageDialog(this, "Ingrese un numero de telefono válido", "Error", JOptionPane.ERROR_MESSAGE);
                        return;
                    }
                    //JOptionPane.showMessageDialog(this, "Venta registrada!", "Éxito", JOptionPane.INFORMATION_MESSAGE);
                    String ced = cedula.getText();
        try{
                if (!ced.matches("\\d{10}")) {
                    JOptionPane.showMessageDialog(this, "Ingrese una cedula válida", "Error", JOptionPane.ERROR_MESSAGE);
                    return;
                }} catch (NumberFormatException e) {
                    JOptionPane.showMessageDialog(this, "Ingrese una cedula válida", "Error", JOptionPane.ERROR_MESSAGE);
                    return;
                }
        MongoClient mongoClient = MongoClients.create("mongodb://localhost:27017");
        MongoDatabase database = mongoClient.getDatabase("ProyectoDeliFrost");
        MongoCollection<Document> collectionn = database.getCollection("RegistroClientes");
        Document query = new Document("Cedula", cedulaa);
        long count = collectionn.countDocuments(query);
        if (count <= 0) {
            JOptionPane.showMessageDialog(this, "Venta registrada!", "Éxito", JOptionPane.INFORMATION_MESSAGE);
     
        } else {
            Oferta e= new Oferta();
            e.setVisible(true);
            e.setLocationRelativeTo(null);
            String finaalValue = finaaal.getText();
            double finaalDouble = Double.parseDouble(finaalValue);
            double result = finaalDouble - (0.10 * finaalDouble);
            finaaal.setText(String.valueOf(result));
            
            }
                }catch (NumberFormatException e) {
                    JOptionPane.showMessageDialog(this, "Ingrese datos validos", "Error", JOptionPane.ERROR_MESSAGE);
                    return;
                }
                nombrec.setText("");
                cedula.setText("");
                telef.setText("");
                totalfinal.setText("");
                iva.setText("");
                //finaaal.setText("");
                DefaultTableModel emptyTableModel = new DefaultTableModel();
                tablafactura.setModel(emptyTableModel);
    }//GEN-LAST:event_button1ActionPerformed

    private void finaaalActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_finaaalActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_finaaalActionPerformed

    private void ivaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ivaActionPerformed
        
    }//GEN-LAST:event_ivaActionPerformed

    private void totalfinalActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_totalfinalActionPerformed
        
    }//GEN-LAST:event_totalfinalActionPerformed

    private void busqueda3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_busqueda3ActionPerformed
        String ced = cedula.getText();
        try{
                if (!ced.matches("\\d{10}")) {
                    JOptionPane.showMessageDialog(this, "Ingrese una cedula válida", "Error", JOptionPane.ERROR_MESSAGE);
                    return;
                }} catch (NumberFormatException e) {
                    JOptionPane.showMessageDialog(this, "Ingrese una cedula válida", "Error", JOptionPane.ERROR_MESSAGE);
                    return;
                }
        MongoClient mongoClient = MongoClients.create("mongodb://localhost:27017");
        MongoDatabase database = mongoClient.getDatabase("ProyectoDeliFrost");
        MongoCollection<Document> collectionn = database.getCollection("RegistroClientes");
        Document query = new Document("Cedula", ced);
        long count = collectionn.countDocuments(query);
        if (count <= 0) {
            JOptionPane.showMessageDialog(this, "El producto ingresado no existe", "Error", JOptionPane.ERROR_MESSAGE);
        } else {
            FindIterable<Document> documents = collectionn.find(query);
            for (Document document : documents) {
            String nom = document.getString("Nombre");
            String tel = document.getString("Teléfono");
            nombrec.setText(nom);
            telef.setText(tel);
            }     
        }    // TODO add your handling code here:
    }//GEN-LAST:event_busqueda3ActionPerformed
    private void ocultarBarra() {
    final int limite = -190;  // Ajusta el valor según tus necesidades
    final int incremento = 2;
    timer = new Timer(1, new ActionListener() {
        @Override
        public void actionPerformed(ActionEvent e) {
            if (jPanel5.getX() > limite) {
                jPanel5.setLocation(jPanel5.getX() - incremento, jPanel5.getY());  // Desplaza la Barra hacia la izquierda
            } else {
                jPanel5.setVisible(false);  // Oculta la Barra cuando alcanza la posición límite
                // Detén el Timer cuando la Barra alcanza la posición límite
                ((Timer) e.getSource()).stop();
            }}});
    // Inicia el Timer
    timer.start();
}
private void iniciarReset() {
    final int limite = 190;  // Ajusta el valor según tus necesidades
    final int incremento = 2;  // Ajusta el valor según tus necesidades
    jPanel5.setVisible(true);
    // Mueve la Barra hacia la izquierda con animación
    timer = new Timer(10, new ActionListener() {
        @Override
        public void actionPerformed(ActionEvent e) {
            if (jPanel5.getX() > limite) {
                jPanel5.setLocation(jPanel5.getX() + incremento, jPanel5.getY());  // Desplaza la Barra hacia la izquierda
            } else {
                  // Oculta la Barra cuando alcanza la posición límite
                // Detén el Timer cuando la Barra alcanza la posición límite
                ((Timer) e.getSource()).stop();
            }
        }
    });
    // Inicia el Timer
    timer.start();
}
    private void cargarDatosDesdeMongooo() {
         FindIterable<Document> documents = mongoNocom.getAllDocumentscollection();
         DefaultTableModel tableModel = new DefaultTableModel();
         tableModel.setColumnIdentifiers(new String[]{ "Código de Producto","Producto","Stock"});
         // Llena el modelo con los datos de MongoDB
         for (Document document : documents) {
             tableModel.addRow(new Object[]{
                 document.get("Código:"),
                 document.get("Producto:"),
                 document.get("Porciones:")
             });} jTable3.setModel(tableModel);
    }
    private void cargarDatosDesdeMongo() {
         FindIterable<Document> documents = mongoInicio.getAllDocumentscollectionn();
         DefaultTableModel tableModel = new DefaultTableModel();
         tableModel.setColumnIdentifiers(new String[]{ "Código","Producto","Porciones"});
         for (Document document : documents) {
             tableModel.addRow(new Object[]{
                 document.get("Código:"),
                 document.get("Producto:"),
                 document.get("Porciones:")
             });}
         Sabores.setModel(tableModel);
    }
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Inventario.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Inventario.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Inventario.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Inventario.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Inventario().setVisible(true);
            }
        });
    }
    // Variables declaration - do not modify//GEN-BEGIN:variables
    private java.awt.Button ActualizarNocom;
    private javax.swing.JTable Aderezos;
    private java.awt.Button GuardarC;
    private java.awt.Button GuardarNocom;
    private javax.swing.JPanel Inventario;
    private javax.swing.JPanel ManualUsuario;
    private javax.swing.JTabbedPane Modificar;
    private javax.swing.JTable Sabores;
    private javax.swing.JPanel Venta;
    private javax.swing.JTable aderezos;
    private java.awt.Button busqueda;
    private java.awt.Button busqueda1;
    private java.awt.Button busqueda3;
    private java.awt.Button busquedaelim;
    private java.awt.Button button1;
    private java.awt.Button button2;
    private java.awt.Button button4;
    private javax.swing.JTextField cedula;
    private javax.swing.JTextField codel;
    private javax.swing.JTextPane codigo;
    private javax.swing.JTextField codigo1;
    private javax.swing.JTextPane comestiblen;
    private java.awt.Button eliminar;
    private javax.swing.JTextField finaaal;
    private java.awt.Button guardar;
    private java.awt.Button guardarNombre;
    private javax.swing.JButton inve;
    private javax.swing.JButton inventario;
    private javax.swing.JTextField iva;
    private javax.swing.JButton jButton1;
    private javax.swing.JComboBox<String> jComboBox1;
    private javax.swing.JDialog jDialog1;
    private javax.swing.JDialog jDialog2;
    private javax.swing.JDialog jDialog3;
    private javax.swing.JFileChooser jFileChooser1;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel13;
    private javax.swing.JLabel jLabel14;
    private javax.swing.JLabel jLabel15;
    private javax.swing.JLabel jLabel16;
    private javax.swing.JLabel jLabel17;
    private javax.swing.JLabel jLabel18;
    private javax.swing.JLabel jLabel19;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel20;
    private javax.swing.JLabel jLabel22;
    private javax.swing.JLabel jLabel23;
    private javax.swing.JLabel jLabel24;
    private javax.swing.JLabel jLabel25;
    private javax.swing.JLabel jLabel26;
    private javax.swing.JLabel jLabel27;
    private javax.swing.JLabel jLabel28;
    private javax.swing.JLabel jLabel29;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel30;
    private javax.swing.JLabel jLabel31;
    private javax.swing.JLabel jLabel33;
    private javax.swing.JLabel jLabel35;
    private javax.swing.JLabel jLabel36;
    private javax.swing.JLabel jLabel37;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JPanel jPanel4;
    private javax.swing.JPanel jPanel5;
    private javax.swing.JPanel jPanel6;
    private javax.swing.JPanel jPanel7;
    private javax.swing.JPanel jPanel9;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane10;
    private javax.swing.JScrollPane jScrollPane11;
    private javax.swing.JScrollPane jScrollPane12;
    private javax.swing.JScrollPane jScrollPane13;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JScrollPane jScrollPane3;
    private javax.swing.JScrollPane jScrollPane4;
    private javax.swing.JScrollPane jScrollPane5;
    private javax.swing.JScrollPane jScrollPane6;
    private javax.swing.JScrollPane jScrollPane7;
    private javax.swing.JScrollPane jScrollPane8;
    private javax.swing.JScrollPane jScrollPane9;
    private javax.swing.JTabbedPane jTabbedPane5;
    private javax.swing.JTable jTable3;
    private javax.swing.JTable jTableEliminar;
    private javax.swing.JTable jTableNombre;
    private javax.swing.JTable jTableStock;
    private javax.swing.JTextPane jTextPane1;
    private javax.swing.JTextField noComestibles2;
    private javax.swing.JTextField nombrec;
    private javax.swing.JTextField nstockC;
    private javax.swing.JTextField nuevoNombre;
    private javax.swing.JTextField nuevostock;
    private java.awt.Panel panel1;
    private javax.swing.JButton registro;
    private javax.swing.JTable sabores;
    private javax.swing.JButton salir;
    private javax.swing.JTextField stock;
    private javax.swing.JTextField stock1;
    private javax.swing.JTextPane stockC;
    private javax.swing.JTable tablafactura;
    private javax.swing.JTextField telef;
    private javax.swing.JTextField totalfinal;
    private javax.swing.JButton venta;
    // End of variables declaration//GEN-END:variables
}