/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package com.mycompany.p2taller1chuicoedith;

import com.mongodb.client.MongoClient;
import com.mongodb.client.MongoClients;
import com.mongodb.client.MongoCollection;
import com.mongodb.client.MongoDatabase;
import java.awt.Graphics;
import java.awt.Image;
import java.awt.geom.RoundRectangle2D;
import java.util.HashSet;
import java.util.Set;
import javax.swing.ImageIcon;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import org.bson.Document;
public class Ingreso extends javax.swing.JFrame {
    FondoPanel fondo= new FondoPanel();
    
    public Ingreso() {
        initComponents();
         RoundRectangle2D.Float shape = new RoundRectangle2D.Float(0, 0, getWidth(), getHeight(), 20, 20);
        setShape(shape);
        //this.setContentPane(fondo);
        
    }
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        Access = new javax.swing.JButton();
        Salir = new javax.swing.JButton();
        Contraseña = new javax.swing.JPasswordField();
        Usuario = new javax.swing.JTextField();
        jLabel1 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setUndecorated(true);
        setPreferredSize(new java.awt.Dimension(1370, 780));
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        Access.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        Access.setBorder(null);
        Access.setOpaque(false);
        Access.setContentAreaFilled(false);
        Access.setBorderPainted(false);
        Access.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                AccessActionPerformed(evt);
            }
        });
        getContentPane().add(Access, new org.netbeans.lib.awtextra.AbsoluteConstraints(650, 580, 230, 60));

        Salir.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        Salir.setBorder(null);
        Salir.setOpaque(false);
        Salir.setContentAreaFilled(false);
        Salir.setBorderPainted(false);
        Salir.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                SalirActionPerformed(evt);
            }
        });
        getContentPane().add(Salir, new org.netbeans.lib.awtextra.AbsoluteConstraints(1300, 30, 40, 40));

        Contraseña.setBackground(new java.awt.Color(205, 76, 130));
        Contraseña.setFont(new java.awt.Font("Segoe UI", 0, 48)); // NOI18N
        Contraseña.setForeground(new java.awt.Color(255, 255, 255));
        Contraseña.setBorder(null);
        Contraseña.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ContraseñaActionPerformed(evt);
            }
        });
        getContentPane().add(Contraseña, new org.netbeans.lib.awtextra.AbsoluteConstraints(340, 480, 850, 70));

        Usuario.setBackground(new java.awt.Color(205, 76, 130));
        Usuario.setFont(new java.awt.Font("Segoe UI", 0, 48)); // NOI18N
        Usuario.setForeground(new java.awt.Color(255, 255, 255));
        Usuario.setBorder(null);
        Usuario.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                UsuarioActionPerformed(evt);
            }
        });
        getContentPane().add(Usuario, new org.netbeans.lib.awtextra.AbsoluteConstraints(340, 380, 850, 70));

        jLabel1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/inicio.png"))); // NOI18N
        getContentPane().add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, -10, 1370, 800));

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void ContraseñaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ContraseñaActionPerformed

    }//GEN-LAST:event_ContraseñaActionPerformed
    
    private void UsuarioActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_UsuarioActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_UsuarioActionPerformed

    private void AccessActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_AccessActionPerformed
        // TODO add your handling code here:
    char[] cl = Contraseña.getPassword();
    String clave = new String(cl);
     String user = Usuario.getText();
        if (!clave.matches("[A-Z]\\d{4}")) {
            JOptionPane.showMessageDialog(this, "Ingrese un código válido ejemplo T1237", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }MongoClient mongoClient = MongoClients.create("mongodb://localhost:27017");
        MongoDatabase database = mongoClient.getDatabase("ProyectoDeliFrost");
        MongoCollection<Document> collectionn = database.getCollection("Vendedores");
        Document query = new Document("CódigoUsuario:", clave);
        Document queryy = new Document("Usuario:", user);
        long count = collectionn.countDocuments(queryy);
        
        if (count <= 0) {
            JOptionPane.showMessageDialog(this, "El usuario ingresado no existe", "Error", JOptionPane.ERROR_MESSAGE);
        } else {
           long countt = collectionn.countDocuments(query);
           if (countt <= 0){
            JOptionPane.showMessageDialog(this, "Codigo incorrecto", "Error", JOptionPane.ERROR_MESSAGE);
           }else{
           Inventario i= new Inventario();
           i.setVisible(true);
           setVisible(false);
           i.setLocationRelativeTo(null);
           }
        }
    }//GEN-LAST:event_AccessActionPerformed

    private void SalirActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_SalirActionPerformed
       System.exit(0); // TODO add your handling code here:
    }//GEN-LAST:event_SalirActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Ingreso.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Ingreso.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Ingreso.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Ingreso.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Ingreso().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton Access;
    private javax.swing.JPasswordField Contraseña;
    private javax.swing.JButton Salir;
    private javax.swing.JTextField Usuario;
    private javax.swing.JLabel jLabel1;
    // End of variables declaration//GEN-END:variables
class FondoPanel extends JPanel{
        
        private Image imagen;
        
        @Override
        public void paint(Graphics g){
            imagen = new ImageIcon(getClass().getResource("/imagenes/RegistroUsuarios.png")).getImage();
            
            g.drawImage(imagen,0,0,getWidth(),getHeight(),this);
        
            setOpaque(false);
            
            super.paint(g);
        }
    }
}
