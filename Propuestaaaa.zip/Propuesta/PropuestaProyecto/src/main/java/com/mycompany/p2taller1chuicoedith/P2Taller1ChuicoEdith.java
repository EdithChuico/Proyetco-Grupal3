package com.mycompany.p2taller1chuicoedith;
public class P2Taller1ChuicoEdith {
    public static void main(String[] args) {
        
        Ingreso c= new Ingreso();
        c.setVisible(true);
        c.setLocationRelativeTo(null);
    }
}
